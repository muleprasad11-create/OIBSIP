Classic Advertising CSV mirror: https://github.com/reisanar/datasets/blob/master/Advertising.csv.
