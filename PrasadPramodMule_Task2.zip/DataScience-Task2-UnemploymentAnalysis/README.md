# UnemploymentAnalysis

**Intern:** Prasad Pramod Mule  
**Track:** Data Science

Descriptive analysis of India unemployment observations with regional ranking, monthly trends, labour-indicator correlation, and a pre/post March 2020 comparison. The historical series and causal limits are documented.

## Run
From this folder, install dependencies with `python -m pip install -r requirements.txt`, then open the notebook in `notebooks/` with Jupyter. Run cells from top to bottom.

## Dataset
CSV mirror: https://github.com/deepanshudagdi/Unemployment-in-India. Commonly circulated dataset: “Unemployment in India” (2019-2020).
