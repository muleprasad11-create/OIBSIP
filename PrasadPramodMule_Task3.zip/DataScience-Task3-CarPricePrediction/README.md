# CarPricePrediction

**Intern:** Prasad Pramod Mule  
**Track:** Data Science

Cleans Bengaluru used-car listings, derives vehicle age, converts price to INR lakh, compares Random Forest and Gradient Boosting with MAE/RMSE/R2, plots residuals, and computes permutation importance.

## Run
From this folder, install dependencies with `python -m pip install -r requirements.txt`, then open the notebook in `notebooks/` with Jupyter. Run cells from top to bottom.

## Dataset
CSV repository: https://github.com/Deepak-Raj-R/cardekho-car-price-dataset. Included Bengaluru listings are a marketplace sample, not a census.
