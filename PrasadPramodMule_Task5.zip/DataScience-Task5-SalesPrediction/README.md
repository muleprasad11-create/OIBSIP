# SalesPrediction

**Intern:** Prasad Pramod Mule  
**Track:** Data Science

Explores the Advertising dataset and compares Linear Regression with Random Forest using MAE/RMSE/R2, residual diagnostics, and channel coefficient interpretation.

## Run
From this folder, install dependencies with `python -m pip install -r requirements.txt`, then open the notebook in `notebooks/` with Jupyter. Run cells from top to bottom.

## Dataset
Classic Advertising CSV mirror: https://github.com/reisanar/datasets/blob/master/Advertising.csv.
