Iris data is bundled with scikit-learn and loaded with sklearn.datasets.load_iris().
