CSV mirror: https://github.com/deepanshudagdi/Unemployment-in-India. Commonly circulated dataset: “Unemployment in India” (2019-2020).
