Official UCI dataset: https://archive.ics.uci.edu/dataset/228/sms+spam+collection. Included as the original tab-separated corpus.
