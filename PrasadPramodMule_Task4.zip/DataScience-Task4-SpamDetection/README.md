# SpamDetection

**Intern:** Prasad Pramod Mule  
**Track:** Data Science

Uses the UCI SMS Spam Collection as a spam-text proxy. Includes preprocessing, TF-IDF, Naive Bayes and Logistic Regression, precision/recall/F1, confusion matrix, and misclassified examples.

## Run
From this folder, install dependencies with `python -m pip install -r requirements.txt`, then open the notebook in `notebooks/` with Jupyter. Run cells from top to bottom.

## Dataset
Official UCI dataset: https://archive.ics.uci.edu/dataset/228/sms+spam+collection. Included as the original tab-separated corpus.
