CSV repository: https://github.com/Deepak-Raj-R/cardekho-car-price-dataset. Included Bengaluru listings are a marketplace sample, not a census.
