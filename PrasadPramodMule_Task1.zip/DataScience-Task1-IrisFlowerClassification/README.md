# IrisFlowerClassification

**Intern:** Prasad Pramod Mule  
**Track:** Data Science

Classification of the built-in Iris dataset with EDA, a pair plot, feature box plots, Logistic Regression and Random Forest, stratified holdout metrics, confusion matrices, and feature importance.

## Run
From this folder, install dependencies with `python -m pip install -r requirements.txt`, then open the notebook in `notebooks/` with Jupyter. Run cells from top to bottom.

## Dataset
Iris data is bundled with scikit-learn and loaded with sklearn.datasets.load_iris().
